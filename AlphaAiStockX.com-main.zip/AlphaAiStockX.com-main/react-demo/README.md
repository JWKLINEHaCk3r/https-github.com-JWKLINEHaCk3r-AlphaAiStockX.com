# AlphaAIStockX - Live Demo Web App

Simple React front-end template for your AI stock research assistant. Ready for Vercel or Netlify deployment.
