// Advanced AI Brain Service - Processes all data for intelligent trading decisions
import { AIBrainService } from '@/tailwind.config';

export const aiBrainService = AIBrainService.getInstance();
