// Types for AI prediction results
export interface Prediction {
  direction: 'BUY' | 'SELL';
  confidence: number;
  [key: string]: unknown;
}
