'use client';

export default function EnhancedVisuals() {
  return <>{/* Enhanced visuals are applied through global CSS */}</>;
}
