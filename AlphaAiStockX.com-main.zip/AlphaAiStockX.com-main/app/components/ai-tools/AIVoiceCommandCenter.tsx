'use client';

// Provide a minimal default export for Next.js dynamic import
export default function AIVoiceCommandCenter() {
  return null;
}
