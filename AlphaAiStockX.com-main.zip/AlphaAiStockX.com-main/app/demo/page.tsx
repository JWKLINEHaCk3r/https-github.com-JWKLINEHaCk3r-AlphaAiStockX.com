export { default } from './auto-trader-demo';
