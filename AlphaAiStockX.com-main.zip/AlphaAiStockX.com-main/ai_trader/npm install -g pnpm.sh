npm install -g pnpm

pnpm install

pnpm dev
