pnpm install
pnpm dev